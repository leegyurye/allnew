#!/bin/bash

cd/work
tar cvzf allnew.tar.gz /work/allnew
mv allnew.tar.gz









