#!/bin/bash

ls -al / > /work/result

