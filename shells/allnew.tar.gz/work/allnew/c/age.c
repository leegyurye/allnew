#include <stdio.h>

int main() {
  int i;
  printf("Input your age : ");
  scanf("%d", &i);
  printf("Your age is %d \n", i);

  return 0;
}
